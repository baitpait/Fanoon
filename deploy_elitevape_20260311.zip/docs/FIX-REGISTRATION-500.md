# إصلاح خطأ 500 في التسجيل (Registration)

## الخطأ

```
POST https://admin.elitevape.online/api/v1/auth/registration 500 (Internal Server Error)
PATH: /api/v1/auth/registration
```

---

## السبب الشائع: أعمدة user_type_id و requested_user_type_id مفقودة

إذا ظهر في السجلات:

```
SQLSTATE[42S22]: Column not found: 1054 Unknown column 'requested_user_type_id' in 'WHERE'
```

فجدول `users` يفتقد الأعمدة. **الحل:**

### الطريقة 1: تشغيل Migration

```bash
php artisan migrate
```

سيُنفّذ الملف: `database/migrations/2026_03_16_000001_add_user_type_columns_to_users.php`

### الطريقة 2: تنفيذ SQL يدوياً (phpMyAdmin أو mysql)

```bash
mysql -u USER -p DATABASE < docs/add_user_type_columns_to_users.sql
```

أو انسخ محتوى `docs/add_user_type_columns_to_users.sql` ونفّذه في phpMyAdmin.

بعد الإصلاح:

```bash
php artisan config:clear
php artisan cache:clear
```

---

## سبب آخر: مفاتيح Passport غير موجودة

عند استدعاء `$user->createToken('RestaurantCustomerAuth')->accessToken` في `CustomerAuthController::registration()`، Laravel Passport يحتاج إلى مفاتيح تشفير موجودة في `storage/`. إذا لم تُنشأ، يظهر:

```
LogicException: Invalid key (Passport)
```

---

## الحل على السيرفر

### 1. إنشاء مفاتيح Passport

اتصل بالسيرفر عبر SSH أو Terminal في cPanel، ثم نفّذ:

```bash
cd /path/to/your/laravel/project
php artisan passport:keys
```

سيُنشئ الملفات:
- `storage/oauth-private.key`
- `storage/oauth-public.key`

### 2. مسح الكاش

```bash
php artisan config:clear
php artisan cache:clear
```

### 3. التأكد من صلاحيات المجلد

```bash
chmod -R 775 storage
chown -R www-data:www-data storage   # أو المستخدم الذي يشغّل الويب
```

---

## أسباب أخرى محتملة

### قاعدة البيانات / OAuth clients

إذا لم تُنشأ جداول Passport أو OAuth clients:

```bash
php artisan migrate
php artisan passport:install
```

> ملاحظة: `passport:install` يشغّل `passport:keys` تلقائياً وينشئ OAuth clients.

### صلاحيات storage

تأكد أن مجلد `storage/` قابل للكتابة:

```bash
chmod -R 775 storage bootstrap/cache
```

### سجلات الخطأ

للتحقق من السبب الفعلي للـ 500:

```bash
tail -50 storage/logs/laravel.log
```

---

## التحقق من نجاح الإصلاح

1. أعد المحاولة من تطبيق Flutter (تسجيل مستخدم جديد).
2. أو اختبر الـ API يدوياً:

```bash
curl -X POST https://admin.elitevape.online/api/v1/auth/registration \
  -H "Content-Type: application/json" \
  -H "X-localization: ar" \
  -d '{"f_name":"Test","l_name":"User","email":"test@example.com","password":"password123"}'
```

---

## مراجع

- `app/Http/Controllers/Api/V1/Auth/CustomerAuthController.php` — دالة `registration()`
- `docs/API-EXAMINATION-REPORT.md` — تقرير فحص الـ API
