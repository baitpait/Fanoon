-- Add user_type_id and requested_user_type_id to users table
-- Fixes: Unknown column 'requested_user_type_id' in 'WHERE'
-- Run this if you imported from elitevape_database_import.sql (old schema)
-- Execute each statement. If you get "Duplicate column" or "Duplicate key", skip that line.

-- 1. Add columns
ALTER TABLE `users` ADD COLUMN `user_type_id` BIGINT UNSIGNED NULL AFTER `login_medium`;
ALTER TABLE `users` ADD COLUMN `requested_user_type_id` BIGINT UNSIGNED NULL AFTER `user_type_id`;

-- 2. Add foreign keys (ensure user_types table has at least id=1)
ALTER TABLE `users` ADD CONSTRAINT `users_user_type_id_foreign` FOREIGN KEY (`user_type_id`) REFERENCES `user_types` (`id`) ON DELETE SET NULL;
ALTER TABLE `users` ADD CONSTRAINT `users_requested_user_type_id_foreign` FOREIGN KEY (`requested_user_type_id`) REFERENCES `user_types` (`id`) ON DELETE SET NULL;
