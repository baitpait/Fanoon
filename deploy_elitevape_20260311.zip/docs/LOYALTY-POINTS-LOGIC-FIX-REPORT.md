# تقرير إصلاح منطق نقاط الولاء

> **التاريخ:** 2026-03-11  
> **المرجع:** نسخة احتياطية `database_backup_anagmgxt_elitevape_2026-03-11_14-21-52.sql`

---

## 1. الأخطاء المكتشفة في البيانات

### 1.1 طلبات بنقاط غير منطقية

| الطلب | loyalty_points_used | loyalty_discount_amount | الملاحظة |
|-------|---------------------|-------------------------|----------|
| 100002 | **1,000,000** | 265.00 | خصم 265 لكن خصم مليون نقطة |
| 100003 | **1,000,000** | 28.00 | خصم 28 لكن خصم مليون نقطة |

### 1.2 سجل loyalty_point_logs

```
id=1: -1000000 (redemption) طلب #100002
id=2: -1000000 (redemption) طلب #100003
```

---

## 2. الخطأ في المنطق

### 2.1 الخلل في `calculateLoyaltyDiscount`

عندما يكون الخصم المحسوب أكبر من إجمالي الطلب، نُحدّ الخصم:

```php
if ($discountAmount > $orderSubtotal) {
    $discountAmount = $orderSubtotal;
}
```

لكن **لم يكن يتم تعديل عدد النقاط المستخدمة**. النتيجة:

- العميل يطلب: 1,000,000 نقطة
- الخصم الفعلي: 265 (محدود)
- النقاط المستخدمة فعلياً: 265 ÷ 0.5 = **530 نقطة**
- ما كان يُحفظ ويُخصم: **1,000,000 نقطة**

### 2.2 استخدام القيمة من الطلب بدل القيمة الفعلية

في `OrderController::placeOrder` كان يتم استخدام `$loyaltyPointsUsed` من الطلب (الـ Request) في:

- `loyalty_points_used` في `orders`
- `LoyaltyPoint::deductPointsForOrder(..., $loyaltyPointsUsed, ...)`

بدلاً من استخدام القيمة الفعلية بعد التحديد.

---

## 3. التعديلات المنفذة

### 3.1 `OrderPricing::calculateLoyaltyDiscount`

- **قبل:** `return float` (قيمة الخصم فقط)
- **بعد:** `return ['discount' => float, 'points_used' => int]`

عند تحديد الخصم:

```php
if ($discountAmount > $orderSubtotal) {
    $discountAmount = $orderSubtotal;
    $effectivePointsUsed = (int) floor($discountAmount / $redemptionValue);
}
```

### 3.2 `OrderPricing::calculateOrderAmount`

- إرجاع `loyalty_points_used` (النقاط الفعلية) في النتيجة:

```php
return [
    ...
    'loyalty_points_used' => $effectivePointsUsed,
];
```

### 3.3 `OrderController::placeOrder`

- استخدام `$effectiveLoyaltyPointsUsed` من نتيجة الحساب بدل قيمة الطلب:

```php
$effectiveLoyaltyPointsUsed = $orderCalculation['loyalty_points_used'] ?? $loyaltyPointsUsed;
// ...
'loyalty_points_used' => $effectiveLoyaltyPointsUsed > 0 ? $effectiveLoyaltyPointsUsed : 0,
// ...
LoyaltyPoint::deductPointsForOrder(..., $effectiveLoyaltyPointsUsed, ...);
```

### 3.4 `StoreOrder` rules

- إضافة `max:1000000` لـ `loyalty_points_used` لتجنب قيم غير عقلانية من الواجهة.

---

## 4. إصلاح البيانات القديمة (اختياري)

إذا أردت تصحيح الطلبات القديمة في قاعدة البيانات:

```sql
-- إعادة حساب النقاط الفعلية للطلبات ذات القيم غير المنطقية
-- مثال: طلب 100002 و 100003
-- loyalty_discount_amount / 0.5 = النقاط الفعلية
-- 265 ÷ 0.5 = 530، 28 ÷ 0.5 = 56

UPDATE orders 
SET loyalty_points_used = FLOOR(loyalty_discount_amount / 0.5)
WHERE loyalty_points_used > 100000 
  AND loyalty_discount_amount > 0;
```

**تحذير:** نفّذ نسخة احتياطية قبل تنفيذ أي تعديل على البيانات. قد تحتاج أيضاً تعديل سجلات `loyalty_point_logs` و `loyalty_points` يدوياً.

---

## 5. الملفات المعدّلة

| الملف | التعديل |
|-------|---------|
| `app/Traits/OrderPricing.php` | إرجاع `points_used` عند تحديد الخصم |
| `app/Http/Controllers/Api/V1/OrderController.php` | استخدام `effectiveLoyaltyPointsUsed` |
| `app/Http/Requests/StoreOrder.php` | إضافة `max:1000000` لـ `loyalty_points_used` |

---

## 6. التحقق من المنطق بعد التعديل

1. **الخصم محدود:** إذا طلب العميل 10000 نقطة وطبقاً للإعدادات الخصم يساوي 5000، لكن إجمالي الطلب 300، فسيُحسب فقط 300 خصم و 600 نقطة مستخدمة.
2. **التسجيل:** يُحفظ `loyalty_points_used = 600` في الطلب.
3. **الخصم من الرصيد:** يُخصم 600 نقطة فقط من رصيد العميل.
