# دليل المبرمج: استخدام loyalty_and_coupon_together في التطبيق

> للمبرمج المسؤول عن تطبيق المتجر (Flutter / Web)

---

## 1. الهدف

إعداد في لوحة التحكم يحدد هل يمكن للعميل استخدام **كوبون الخصم** و **نقاط الولاء** معاً في نفس الطلب.

| القيمة | المعنى |
|--------|--------|
| `1` | مسموح — يمكن استخدام الاثنين معاً |
| `0` | ممنوع — يجب اختيار واحد فقط |

---

## 2. الحصول على الإعداد

### 2.1 من API الإعدادات

```
GET /api/v1/config
```

**لا يتطلب مصادقة.**

**Response (200):**
```json
{
  "loyalty_points_enabled": 1,
  "loyalty_amount_for_one_point": 10,
  "loyalty_points_per_amount": 1,
  "loyalty_point_redemption_value": 0.5,
  "loyalty_and_coupon_together": 1,
  "loyalty_levels": { ... }
}
```

**الحقل المطلوب:**
- `loyalty_and_coupon_together` — `1` أو `0` (integer)

---

## 3. كيفية الاستخدام في التطبيق

### 3.1 عند فتح التطبيق

1. استدعِ `GET /api/v1/config`
2. احفظ `loyalty_and_coupon_together` في حالة التطبيق (مثلاً في Provider أو State)

### 3.2 في شاشة السلة / الدفع

| loyalty_and_coupon_together | السلوك المقترح |
|----------------------------|-----------------|
| `1` | عرض خيار الكوبون وخيار النقاط بشكل مستقل — يمكن تفعيل الاثنين |
| `0` | عند تفعيل الكوبون → إخفاء أو تعطيل خيار النقاط، والعكس |

### 3.3 منطق الواجهة المقترح

```
إذا loyalty_and_coupon_together == 0:
  - إذا وُجد كوبون مطبّق:
      → إخفاء/تعطيل حقل "استخدام نقاط الولاء"
      → أو إظهار رسالة: "لا يمكن استخدام النقاط مع الكوبون"
  - إذا وُجدت نقاط ولاء مستخدمة:
      → إخفاء/تعطيل حقل "كود الكوبون"
      → أو إظهار رسالة: "لا يمكن استخدام الكوبون مع النقاط"

إذا loyalty_and_coupon_together == 1:
  - السماح بتفعيل الكوبون والنقاط معاً (السلوك الحالي)
```

### 3.4 عند إرسال الطلب

```
POST /api/v1/customer/order/place
```

| loyalty_and_coupon_together | ماذا ترسل |
|-----------------------------|-----------|
| `1` | يمكن إرسال `coupon_code` و `loyalty_points_used` معاً |
| `0` | أرسل واحداً فقط — إما `coupon_code` أو `loyalty_points_used` |

**إذا أرسلت الاثنين معاً والإعداد = 0:**

**Response (422):**
```json
{
  "errors": [
    {
      "code": "loyalty_points_used",
      "message": "يجب اختيار الكوبون أو نقاط الولاء فقط — لا يمكن استخدامهما معاً"
    }
  ]
}
```

---

## 4. أمثلة كود (مفهومية)

### 4.1 Flutter — التحقق قبل الإرسال

```dart
bool get canUseLoyaltyWithCoupon =>
    config.loyaltyAndCouponTogether == 1;

void onCouponApplied(String? code) {
  if (code != null && !canUseLoyaltyWithCoupon) {
    setState(() => loyaltyPointsUsed = 0); // إلغاء النقاط
  }
}

void onLoyaltyPointsChanged(int points) {
  if (points > 0 && !canUseLoyaltyWithCoupon && couponCode != null) {
    showMessage('لا يمكن استخدام النقاط مع الكوبون');
    return;
  }
}
```

### 4.2 إخفاء/إظهار الحقل

```dart
// إظهار خيار النقاط فقط إذا:
// - النقاط مفعّلة
// - وإما لا يوجد كوبون، أو loyalty_and_coupon_together == 1
bool get showLoyaltyOption =>
    config.loyaltyPointsEnabled &&
    (couponCode == null || config.loyaltyAndCouponTogether == 1);
```

---

## 5. اختبار الـ API

### 5.1 التحقق من الإعداد

```bash
curl -X GET "https://admin.elitevape.online/api/v1/config" \
  -H "X-localization: ar"
```

تأكد من وجود `loyalty_and_coupon_together` في الاستجابة.

### 5.2 اختبار الرفض (عند التعطيل)

1. في لوحة التحكم: عطّل "السماح باستخدام النقاط والكوبون معاً"
2. أرسل طلباً يحتوي على `coupon_code` و `loyalty_points_used` معاً
3. يجب أن تحصل على 422 مع رسالة الخطأ أعلاه

### 5.3 اختبار القبول (عند التفعيل)

1. في لوحة التحكم: فعّل "السماح باستخدام النقاط والكوبون معاً"
2. أرسل طلباً يحتوي على الاثنين
3. يجب أن ينجح الطلب (200)

---

## 6. ملخص للمبرمج

| الخطوة | الإجراء |
|--------|---------|
| 1 | قراءة `loyalty_and_coupon_together` من `GET /api/v1/config` |
| 2 | عند `0`: منع إرسال الاثنين معاً في الواجهة |
| 3 | عند `0`: إخفاء أو تعطيل أحد الخيارين عند تفعيل الآخر |
| 4 | عند `1`: السماح باستخدام الاثنين معاً كما هو الحال حالياً |
| 5 | التعامل مع رسالة الخطأ 422 عند إرسال الاثنين معاً رغم التعطيل |
