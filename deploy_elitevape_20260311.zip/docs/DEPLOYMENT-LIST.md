# قائمة الملفات المعدّلة للنشر على السيرفر

> **التاريخ:** 2026-03-11  
> انسخ هذه الملفات إلى مجلد المشروع على السيرفر مع الحفاظ على المسارات.

---

## 1. Migrations (قاعدة البيانات)

| الملف | المسار الكامل |
|-------|---------------|
| إضافة أعمدة user_type | `database/migrations/2026_03_16_000001_add_user_type_columns_to_users.php` |
| إعداد loyalty_and_coupon_together | `database/migrations/2026_03_16_000002_add_loyalty_and_coupon_together_setting.php` |

---

## 2. التطبيق (App)

| الملف | المسار |
|-------|--------|
| OrderPricing | `app/Traits/OrderPricing.php` |
| OrderController | `app/Http/Controllers/Api/V1/OrderController.php` |
| ConfigController | `app/Http/Controllers/Api/V1/ConfigController.php` |
| BusinessSettingsController | `app/Http/Controllers/Admin/BusinessSettingsController.php` |
| StoreOrder | `app/Http/Requests/StoreOrder.php` |

---

## 3. الواجهات (Views)

| الملف | المسار |
|-------|--------|
| إعدادات التجارة الإلكترونية | `resources/views/admin-views/business-settings/ecom-setup.blade.php` |

---

## 4. الترجمات (Lang)

| الملف | المسار |
|-------|--------|
| العربية | `resources/lang/ar/messages.php` |
| الإنجليزية | `resources/lang/en/messages.php` |

---

## 5. الاختبارات (Tests)

| الملف | المسار |
|-------|--------|
| LoyaltyCouponTogetherApiTest | `tests/Feature/LoyaltyCouponTogetherApiTest.php` |

---

## 6. التوثيق (اختياري)

| الملف | المسار |
|-------|--------|
| إصلاح تسجيل 500 | `docs/FIX-REGISTRATION-500.md` |
| SQL يدوي لأعمدة user_type | `docs/add_user_type_columns_to_users.sql` |
| تقرير إصلاح نقاط الولاء | `docs/LOYALTY-POINTS-LOGIC-FIX-REPORT.md` |
| دليل المبرمج Flutter | `docs/FLUTTER-LOYALTY-COUPON-TOGETHER-GUIDE.md` |

---

## خطوات النشر

1. **نسخ الملفات** إلى مجلد المشروع على السيرفر (مثلاً `/var/www/elitevape` أو `public_html`).

2. **تشغيل الـ migrations:**
   ```bash
   cd /path/to/project
   php artisan migrate
   ```

3. **مسح الكاش (اختياري):**
   ```bash
   php artisan config:clear
   php artisan cache:clear
   php artisan view:clear
   ```

4. **تأكيد الاختبارات (اختياري):**
   ```bash
   php artisan test tests/Feature/LoyaltyCouponTogetherApiTest.php
   ```

---

## ملاحظات

- إذا كان جدول `users` لا يحتوي على `user_type_id` و `requested_user_type_id`، سيتم إضافتهما عبر `2026_03_16_000001_add_user_type_columns_to_users.php`.
- إذا كان جدول `business_settings` لا يحتوي على `loyalty_and_coupon_together`، سيتم إضافته عبر `2026_03_16_000002_add_loyalty_and_coupon_together_setting.php`.
- احتفظ بنسخة احتياطية من قاعدة البيانات قبل التشغيل.
