========================================
  نشر التحديثات على السيرفر - Elite Vape
  التاريخ: 2026-03-11
========================================

الخطوات:
--------
1. انسخ ملف deploy_elitevape_20260311.zip إلى السيرفر

2. انتقل لمجلد المشروع (مثلاً: cd /var/www/elitevape أو public_html)

3. فك الضغط فوق المجلد الحالي:
   unzip deploy_elitevape_20260311.zip

4. انسخ الملفات فوق الملفات الموجودة (ستستبدل التعديلات):
   - إذا فككت داخل مجلد المشروع مباشرة، الملفات ستستبدل تلقائياً
   - إذا فككت في مكان آخر، انسخ app/ database/ resources/ tests/ إلى جذر المشروع

5. تشغيل الـ migrations:
   php artisan migrate

6. مسح الكاش:
   php artisan config:clear
   php artisan cache:clear
   php artisan view:clear

7. (اختياري) تشغيل الاختبارات:
   php artisan test tests/Feature/LoyaltyCouponTogetherApiTest.php

ملاحظة: احتفظ بنسخة احتياطية من المشروع وقاعدة البيانات قبل النشر.
